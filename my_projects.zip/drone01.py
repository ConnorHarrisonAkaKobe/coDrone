from codrone_edu.drone import *  

drone = Drone()                 
drone.pair()                      

battery = drone.get_battery()    
print("Battery:", battery, "%")    

drone.set_drone_LED(0, 255, 0, 100)   
drone.drone_buzzer(440, 500)    # 440 Hz for 500 milliseconds
drone.takeoff()      
drone.hover(3)      
drone.land()         

drone.close()                    