from codrone_edu.drone import *    
import time

drone = Drone()                   
drone.pair()                   

drone.drone_buzzer(392, 200)
drone.drone_buzzer(392, 200)
drone.drone_buzzer(392, 200)
drone.drone_buzzer(392, 200)
drone.drone_buzzer(392, 200)


drone.set_drone_LED(0, 0, 255, 100)
time.sleep(.1) 
drone.set_drone_LED(0, 255, 0, 100)      # green: flying
time.sleep(.1) 
drone.set_drone_LED(255, 255, 0, 100)
time.sleep(.1)
drone.set_drone_LED(128, 0,	128, 0)
time.sleep(.1)
drone.set_drone_LED(0, 0, 255, 100)
time.sleep(.1) 
drone.set_drone_LED(0, 255, 0, 100)      # green: flying
time.sleep(.1) 
drone.set_drone_LED(255, 255, 0, 100)
time.sleep(.1)
drone.set_drone_LED(128, 0,	128, 0)
time.sleep(.1)
drone.set_drone_LED(0, 0, 255, 100)
time.sleep(.1) 
drone.set_drone_LED(0, 255, 0, 100)      # green: flying
time.sleep(.1) 
drone.set_drone_LED(255, 255, 0, 100)
time.sleep(.1)
drone.set_drone_LED(128, 0,	128, 0)
time.sleep(.1)
drone.set_drone_LED(0, 0, 255, 100)
time.sleep(.1) 
drone.set_drone_LED(0, 255, 0, 100)      # green: flying
time.sleep(.1) 
drone.set_drone_LED(255, 255, 0, 100)
time.sleep(.1)
drone.set_drone_LED(128, 0,	128, 0)
time.sleep(.1)

drone.takeoff()

drone.set_drone_LED(0, 0, 255, 100)
time.sleep(.1) 
drone.set_drone_LED(0, 255, 0, 100)      # green: flying
time.sleep(.1) 
drone.set_drone_LED(255, 255, 0, 100)
time.sleep(.1)
drone.set_drone_LED(128, 0,	128, 0)
time.sleep(.1)

drone.flip("back") 

drone.set_drone_LED(0, 0, 255, 100)
time.sleep(.1) 
drone.set_drone_LED(0, 255, 0, 100)      # green: flying
time.sleep(.1) 
drone.set_drone_LED(255, 255, 0, 100)
time.sleep(.1)
drone.set_drone_LED(128, 0,	128, 0)
time.sleep(.1)

drone.land()

drone.drone_buzzer(262, 400)
drone.drone_LED_off()

drone.close()                  